package Controleur;

import static Model.Database_conection.getConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;
import Vue.Clients;
import Model.Client_Model;

public class Client_controleur {

    Connection connexion;
    PreparedStatement statment;
    ResultSet result;

    private void ajouterClient(Client_Model client) {
        try {
            getConnection();
            statment = connexion.prepareStatement("INSERT INTO clients_vue(nom_client, prenon_client, telephone, status_fidelite, status_etranger) VALUES (?, ?, ?, ?, ?)");
            statment.setString(1, client.getNom());
            statment.setString(2, client.getPrenon());
            statment.setString(3, client.getNationalite());
            statment.setString(4, String.valueOf(client.getTelephone()));
            statment.setString(5, client.getStatusetranger());

            statment.executeUpdate();
            connexion.close();
            JOptionPane.showMessageDialog(null, "client ajouter avec succes");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    /*public void actionPerformed(ActionEvent e) {
    if (ouiRadioButton.isSelected()) {
        // Créer un nouveau label
        JLabel nouveauLabel = new JLabel("Client fidèle");
        mainPanel.add(nouveauLabel);

        // Ajouter une image
        ImageIcon image = new ImageIcon("chemin/vers/votre/image.png");
        JLabel imageLabel = new JLabel(image);
        mainPanel.add(imageLabel);

        // Créer un numéro de fidélité label
        JLabel numeroFideliteLabel = new JLabel("Numéro de fidélité:");
        mainPanel.add(numeroFideliteLabel);

        // Créer un champ de texte pour le numéro de fidélité
        JTextField numeroFideliteTextField = new JTextField();
        mainPanel.add(numeroFideliteTextField);

        // Créer un champ de texte pour la date
        JLabel dateLabel = new JLabel("Date:");
        mainPanel.add(dateLabel);

        // Créer un champ de texte pour la date
        JTextField dateTextField = new JTextField();
        mainPanel.add(dateTextField);

        // Rafraîchir l'interface utilisateur
        frame.validate();
        frame.repaint();
    }
}*/

}
