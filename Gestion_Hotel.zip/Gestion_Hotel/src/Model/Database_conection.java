package Model;
import java.sql.*;


public class Database_conection {
     public static Connection getConnection() {
        Connection connexion = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception ex) {
            System.err.println(ex.getMessage());
        }
        try {
            connexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/Gestion_Hotel", "root", "");
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return connexion;
    }
     public static void main(String[]args){
         Database_conection dbConnection = new Database_conection();
        Connection connection = dbConnection.getConnection();

        if (connection != null) {
            System.out.println("Connexion à la base de données établie avec succès.");
            // Vous pouvez maintenant utiliser "connection" pour interagir avec la base de données.
            // Par exemple, exécutez des requêtes SQL, insérez, mettez à jour, supprimez des données, etc.
        } else {
            System.out.println("La connexion à la base de données a échoué.");
        }
    }
}
     


    

