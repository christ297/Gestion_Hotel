/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author christ
 */
public class Client_Model {

    private String nomclient;
    private String prenonclient;
    private String nationalite;
    private int telephone;
    private String carteFideliter;
    private String statusEtranger;

    public Client_Model(String nomclient,
            String prenonclient,
            String nationalite,
            int telephone,
            String carteFideliter,
            String statusEtranger) 
    {this.nomclient=nomclient;
    this.prenonclient=prenonclient;
    this.nationalite=nationalite;
    this.telephone=telephone;
    this.carteFideliter=carteFideliter;
    this.statusEtranger=statusEtranger;

    }


    public String getNom() {
        return nomclient;
    }

    public String getPrenon() {
        return prenonclient;
    }

    public String getNationalite() {
        return nationalite;
    }

    public int getTelephone() {
        return telephone;
    }

    public String getCartefidelite() {
        return carteFideliter;
    }

    public String getStatusetranger() {
        return statusEtranger;
    }

}
